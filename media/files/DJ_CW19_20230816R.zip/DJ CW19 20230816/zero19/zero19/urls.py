from django.contrib import admin
from django.urls import path, re_path
from app.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', OneView.as_view(), name='list'),
    path('create', OneCreate.as_view(), name='create'),
    path('delete/<int:id>', OneDelete.as_view(), name='delete')
]
