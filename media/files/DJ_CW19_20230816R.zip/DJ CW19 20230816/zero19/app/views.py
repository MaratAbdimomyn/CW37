from django.shortcuts import render
from django.views.generic import ListView, DetailView, DeleteView, CreateView
from .models import One
from django.urls import reverse, reverse_lazy

class OneView(ListView):
    model = One
    template_name = 'list.html'
    context_object_name = 'ones'

class OneCreate(CreateView):
    model = One
    template_name = 'create.html'
    success_url = reverse_lazy('list') 
    fields = ['name']

class OneDelete(DeleteView):
    model = One
    pk_url_kwarg = "id"
    success_url = reverse_lazy('list')

"""class ToDoView(ListView):
    model = ToDo
    template_name = 'list.html'
    context_object_name = 'todos'


class ToDoDeleteView(DeleteView):
    model = ToDo
    template_name = 'todo_confirm_delete.html'
    success_url = reverse_lazy('list')


class CreateTodoView(CreateView):
    model = ToDo
    template_name = 'todo_form.html'
    success_url = reverse_lazy('list') 
    fields = ['title', 'body', 'deadline']

class ToDoDetails(DetailView):
    model = ToDo
    template_name = 'details.html'
    context_object_name = 'todo'
    pk_url_kwarg = 'id'  

    def post(self, request, *args, **kwargs):
        task = self.get_object()
        task.status = True
        task.save()
        return HttpResponseRedirect(reverse('list'))"""